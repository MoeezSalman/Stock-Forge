"""
sentiment_seeder.py
====================
Processes hardcoded financial news articles through HuggingFace FinBERT
and stores ALL dashboard-ready data in MongoDB.

Collections written:
  - sentiment_articles     (per-article results with tokens)
  - sentiment_stats        (aggregate stats for stat cards)
  - sentiment_timeline     (30-day rolling data)
  - sentiment_sources      (per-source breakdown)
  - sentiment_keywords     (top keyword cloud)

Run:
    pip install pymongo httpx python-dotenv certifi
    python sentiment_seeder.py
"""

import os, asyncio, httpx, certifi, re
from datetime import datetime, timedelta
from collections import defaultdict
from dotenv import load_dotenv
from pymongo import MongoClient

load_dotenv()

# ── Config ─────────────────────────────────────────────────────────────────────
MONGO_URI  = os.getenv("MONGO_URI", "mongodb+srv://Priorify:1234567890@moeezdatabases.nyxyde8.mongodb.net/StockForge")
DB_NAME    = "StockForge"
HF_API_URL = "https://router.huggingface.co/hf-inference/models/ProsusAI/finbert"
HF_API_KEY = os.getenv("HF_API_KEY", "")

# ── Hardcoded Financial News Articles ─────────────────────────────────────────
ARTICLES = [
    # Bloomberg – AAPL positive
    {"source": "Bloomberg", "ticker": "AAPL", "published_offset_hours": 0.2,
     "headline": "Apple reports record iPhone sales in Q2, beats analyst expectations by 8%"},
    {"source": "Bloomberg", "ticker": "AAPL", "published_offset_hours": 1.5,
     "headline": "Apple's services revenue hits all-time high as App Store subscriptions surge"},
    {"source": "Bloomberg", "ticker": "NVDA", "published_offset_hours": 2.0,
     "headline": "NVIDIA announces next-gen Blackwell GPU with unprecedented AI training performance"},
    {"source": "Bloomberg", "ticker": "MSFT", "published_offset_hours": 3.0,
     "headline": "Microsoft Azure revenue jumps 28% driven by enterprise AI adoption"},
    {"source": "Bloomberg", "ticker": "AAPL", "published_offset_hours": 4.0,
     "headline": "Analyst upgrades AAPL to Strong Buy citing robust AI integration roadmap"},

    # Reuters – mixed
    {"source": "Reuters", "ticker": "AAPL", "published_offset_hours": 1.2,
     "headline": "Supply chain concerns in Asia may limit Apple production capacity this quarter"},
    {"source": "Reuters", "ticker": "TSLA", "published_offset_hours": 2.5,
     "headline": "Tesla deliveries beat estimates as EV demand rebounds in key markets"},
    {"source": "Reuters", "ticker": "GOOGL", "published_offset_hours": 5.0,
     "headline": "Google Search ad revenue accelerates on AI-powered query expansion"},
    {"source": "Reuters", "ticker": "MSFT", "published_offset_hours": 6.0,
     "headline": "Microsoft to acquire AI startup in deal valued at $1.5 billion"},
    {"source": "Reuters", "ticker": "NVDA", "published_offset_hours": 7.0,
     "headline": "NVIDIA chip export restrictions to China weigh on near-term revenue outlook"},

    # CNBC – mixed
    {"source": "CNBC", "ticker": "AAPL", "published_offset_hours": 1.2,
     "headline": "EU continues regulatory scrutiny of Apple App Store market practices"},
    {"source": "CNBC", "ticker": "TSLA", "published_offset_hours": 3.0,
     "headline": "Tesla faces increased competition from BYD in European market segment"},
    {"source": "CNBC", "ticker": "GOOGL", "published_offset_hours": 4.5,
     "headline": "Antitrust lawsuit against Google could reshape digital advertising market"},
    {"source": "CNBC", "ticker": "NVDA", "published_offset_hours": 6.0,
     "headline": "NVIDIA data center revenue hits record as hyperscalers ramp AI infrastructure"},
    {"source": "CNBC", "ticker": "AMZN", "published_offset_hours": 8.0,
     "headline": "Amazon AWS growth reaccelerates to 17% as cloud demand strengthens"},

    # WSJ – mostly positive
    {"source": "WSJ", "ticker": "AAPL", "published_offset_hours": 2.0,
     "headline": "Fed signals potential rate cuts could boost tech sector valuations significantly"},
    {"source": "WSJ", "ticker": "MSFT", "published_offset_hours": 3.5,
     "headline": "Microsoft Copilot adoption accelerates across Fortune 500 enterprise clients"},
    {"source": "WSJ", "ticker": "AMZN", "published_offset_hours": 5.0,
     "headline": "Amazon logistics efficiency gains drive operating margin expansion to record levels"},
    {"source": "WSJ", "ticker": "GOOGL", "published_offset_hours": 7.0,
     "headline": "Alphabet buyback program signals management confidence in long-term growth"},
    {"source": "WSJ", "ticker": "TSLA", "published_offset_hours": 9.0,
     "headline": "Tesla energy storage business emerges as significant profit driver this quarter"},

    # FT – neutral/mixed
    {"source": "FT", "ticker": "AAPL", "published_offset_hours": 5.5,
     "headline": "Apple's India manufacturing expansion faces infrastructure and regulatory hurdles"},
    {"source": "FT", "ticker": "NVDA", "published_offset_hours": 6.5,
     "headline": "AI chip demand remains robust but inventory correction risk looms for late 2025"},
    {"source": "FT", "ticker": "MSFT", "published_offset_hours": 8.0,
     "headline": "Microsoft gaming division faces uncertainty as mobile market growth slows"},
    {"source": "FT", "ticker": "AMZN", "published_offset_hours": 10.0,
     "headline": "Amazon union activity intensifies at multiple US warehouse locations"},
    {"source": "FT", "ticker": "GOOGL", "published_offset_hours": 11.0,
     "headline": "Global macro headwinds could dampen digital advertising spend in H2"},

    # Twitter/X – mostly negative/volatile
    {"source": "Twitter/X", "ticker": "TSLA", "published_offset_hours": 0.5,
     "headline": "TSLA short interest at 6-month high as delivery miss fears mount"},
    {"source": "Twitter/X", "ticker": "NVDA", "published_offset_hours": 1.0,
     "headline": "NVDA valuation looks stretched at 40x forward earnings says hedge fund"},
    {"source": "Twitter/X", "ticker": "AAPL", "published_offset_hours": 2.0,
     "headline": "Apple Vision Pro sales disappointing analysts with demand far below projections"},
    {"source": "Twitter/X", "ticker": "AMZN", "published_offset_hours": 3.5,
     "headline": "Amazon layoffs in AWS division raise concerns about cloud growth sustainability"},
    {"source": "Twitter/X", "ticker": "MSFT", "published_offset_hours": 4.0,
     "headline": "Microsoft AI spending could weigh heavily on near-term free cash flow margins"},

    # MarketWatch – positive
    {"source": "MarketWatch", "ticker": "NVDA", "published_offset_hours": 1.0,
     "headline": "NVIDIA gross margins expand to 78% as premium AI chip pricing holds firm"},
    {"source": "MarketWatch", "ticker": "AAPL", "published_offset_hours": 2.5,
     "headline": "Apple dividend increase and buyback expansion signal financial strength"},
    {"source": "MarketWatch", "ticker": "AMZN", "published_offset_hours": 4.0,
     "headline": "Amazon Prime membership growth accelerates globally with new content slate"},
    {"source": "MarketWatch", "ticker": "TSLA", "published_offset_hours": 6.0,
     "headline": "Tesla Full Self-Driving v13 receives positive early user reviews and safety data"},
    {"source": "MarketWatch", "ticker": "GOOGL", "published_offset_hours": 8.0,
     "headline": "Google DeepMind breakthrough in protein folding could unlock massive pharma licensing"},
]

# ── Keyword definitions for token-level tagging ───────────────────────────────
POSITIVE_KEYWORDS = [
    "record","beats","beat","strong","upgrade","upgrades","surge","surges","growth",
    "profit","boost","high","best","accelerates","robust","expansion","positive",
    "strength","efficient","breakthrough","improves","rebound","rebounded","jumps",
    "hit","hits","significant","adoption","increase","confidence","wins","premier",
    "leading","innovation","milestone","outperform","outperforms","dominant",
]
NEGATIVE_KEYWORDS = [
    "concern","concerns","risk","risks","limit","limits","scrutiny","antitrust",
    "lawsuit","competition","decline","loss","losses","layoffs","weigh","weighs",
    "correction","disappointing","miss","fears","stretched","uncertainty","hurdles",
    "slows","intensifies","headwinds","short","dampen","looms","regulatory",
    "restriction","restrictions","below","burden","vulnerable","worries","volatile",
]

def tag_tokens(headline: str):
    """Split headline into words and tag each as pos/neg/neu."""
    words = re.findall(r"\b\w[\w'%+\-]*\b|[^\w\s]", headline)
    tagged = []
    for w in words:
        wl = w.lower()
        if wl in POSITIVE_KEYWORDS:
            tagged.append({"w": w, "s": "pos"})
        elif wl in NEGATIVE_KEYWORDS:
            tagged.append({"w": w, "s": "neg"})
        else:
            tagged.append({"w": w, "s": "neu"})
    return tagged

def extract_keywords(articles_with_results):
    """Pull top sentiment-bearing keywords from all headlines."""
    freq = defaultdict(lambda: {"count": 0, "sentiment": "neu"})
    for art in articles_with_results:
        for token in art.get("tokens", []):
            if token["s"] in ("pos", "neg"):
                key = token["w"].lower()
                freq[key]["count"] += 1
                freq[key]["sentiment"] = token["s"]
    sorted_kw = sorted(freq.items(), key=lambda x: x[1]["count"], reverse=True)[:16]
    return [{"keyword": k, "sentiment": v["sentiment"], "count": v["count"]} for k, v in sorted_kw]

def build_timeline(articles_with_results, days=30):
    """Build a 30-point daily sentiment timeline."""
    now = datetime.utcnow()
    timeline = []
    for i in range(days - 1, -1, -1):
        day = now - timedelta(days=i)
        label = day.strftime("%b %d").replace(" 0", " ")
        day_arts = [a for j, a in enumerate(articles_with_results) if j % days == (days - 1 - i) % len(articles_with_results)]
        if not day_arts:
            score = timeline[-1]["score"] if timeline else 0.5
        else:
            scores = []
            for a in day_arts:
                lbl = a["label"]
                s   = a["score"]
                scores.append(s if lbl == "positive" else (-s if lbl == "negative" else 0))
            score = round(sum(scores) / len(scores), 4)
        timeline.append({"label": label, "score": score, "date": day.strftime("%Y-%m-%d")})
    return timeline

def build_source_stats(articles_with_results):
    """Per-source aggregated sentiment."""
    source_data = defaultdict(lambda: {"scores": [], "labels": []})
    for art in articles_with_results:
        s = art["source"]
        lbl = art["label"]
        score = art["score"] if lbl == "positive" else (-art["score"] if lbl == "negative" else 0)
        source_data[s]["scores"].append(score)
        source_data[s]["labels"].append(lbl)

    results = []
    for source, data in source_data.items():
        avg_score = round(sum(data["scores"]) / len(data["scores"]), 2) if data["scores"] else 0
        count     = len(data["scores"])
        pos_pct   = round(data["labels"].count("positive") / count * 100)
        results.append({
            "source":    source,
            "count":     count,
            "avg_score": avg_score,
            "score_str": f"+{avg_score}" if avg_score >= 0 else str(avg_score),
            "pos_pct":   pos_pct,
        })
    return sorted(results, key=lambda x: x["avg_score"], reverse=True)

# ── HuggingFace FinBERT call (true batch) ─────────────────────────────────────
async def run_finbert_batch(texts: list[str]) -> list[dict]:
    headers = {
        "Authorization": f"Bearer {HF_API_KEY}",
        "Content-Type": "application/json"
    }

    async with httpx.AsyncClient(timeout=120) as client:
        for attempt in range(3):
            print(f"  Sending {len(texts)} headlines to FinBERT (attempt {attempt + 1}/3)...")
            resp = await client.post(
                HF_API_URL,
                headers=headers,
                json={
                    "inputs": texts,
                    "options": {"wait_for_model": True}   # wait for cold-start
                }
            )

            if resp.status_code == 503:
                print(f"  Model still loading, waiting 20s...")
                await asyncio.sleep(20)
                continue

            if resp.status_code != 200:
                raise RuntimeError(f"HuggingFace error {resp.status_code}: {resp.text}")

            result = resp.json()

            # Normalize: single input → flat list of dicts, batch → list of lists
            if result and isinstance(result[0], dict):
                result = [result]

            print(f"  ✓ Received {len(result)} results")
            return result

    raise RuntimeError("FinBERT model failed to respond after 3 attempts. Try again in a minute.")


# ── Main seeder ───────────────────────────────────────────────────────────────
async def main():
    print("=" * 60)
    print("StockForge Sentiment Seeder")
    print("=" * 60)

    if not HF_API_KEY:
        print("⚠️  WARNING: HF_API_KEY is not set. Requests may be rate-limited.")

    # 1. Run all headlines through FinBERT in batches of 20
    headlines   = [a["headline"] for a in ARTICLES]
    all_results = []
    BATCH       = 20

    for i in range(0, len(headlines), BATCH):
        batch      = headlines[i:i + BATCH]
        batch_num  = i // BATCH + 1
        print(f"\n[FinBERT] Batch {batch_num}: {len(batch)} headlines...")
        raw = await run_finbert_batch(batch)
        all_results.extend(raw)
        print(f"  ✓ Batch {batch_num} complete")

    # 2. Enrich articles with FinBERT results
    now      = datetime.utcnow()
    enriched = []

    print("\n[Processing] Enriching articles...")
    for idx, (art, scores) in enumerate(zip(ARTICLES, all_results)):
        best   = max(scores, key=lambda x: x["score"])
        label  = best["label"].lower()
        score  = round(best["score"], 4)
        tokens = tag_tokens(art["headline"])
        enriched.append({
            **art,
            "label":        label,
            "score":        score,
            "confidence":   score,
            "all_scores":   scores,
            "tokens":       tokens,
            "published_at": (now - timedelta(hours=art["published_offset_hours"])).isoformat(),
            "seeded_at":    now.isoformat(),
            "score_str":    f"+{score:.2f}" if label == "positive" else (f"−{score:.2f}" if label == "negative" else f"{score:.2f}"),
            "score_display": (
                f"+{score:.2f} Positive" if label == "positive"
                else (f"−{score:.2f} Negative" if label == "negative" else f"{score:.2f} Neutral")
            ),
        })
        print(f"  [{label.upper():8s} {score:.2f}] {art['headline'][:70]}")

    # 3. Aggregate stats
    total    = len(enriched)
    pos      = [a for a in enriched if a["label"] == "positive"]
    neg      = [a for a in enriched if a["label"] == "negative"]
    neu      = [a for a in enriched if a["label"] == "neutral"]
    pos_pct  = round(len(pos) / total * 100, 1)
    avg_conf = round(sum(a["confidence"] for a in enriched) / total * 100, 1)

    def signed_score(a):
        if a["label"] == "positive": return a["score"]
        if a["label"] == "negative": return -a["score"]
        return 0.0

    overall_sent = round(sum(signed_score(a) for a in enriched) / total, 4)

    stats = {
        "articles_processed":    total,
        "overall_sentiment":     overall_sent,
        "overall_sentiment_str": f"+{overall_sent}" if overall_sent >= 0 else str(overall_sent),
        "positive_rate":         pos_pct,
        "positive_count":        len(pos),
        "negative_count":        len(neg),
        "neutral_count":         len(neu),
        "nlp_confidence":        avg_conf,
        "generated_at":          now.isoformat(),
        "sentiment_bias":        "Bullish" if overall_sent > 0.1 else ("Bearish" if overall_sent < -0.1 else "Neutral"),
    }

    timeline = build_timeline(enriched)
    sources  = build_source_stats(enriched)
    keywords = extract_keywords(enriched)

    # 4. Write to MongoDB
    print("\n[MongoDB] Connecting...")
    client = MongoClient(MONGO_URI, tls=True, tlsCAFile=certifi.where())
    db     = client[DB_NAME]

    for col in ["sentiment_articles", "sentiment_stats", "sentiment_timeline",
                "sentiment_sources",  "sentiment_keywords"]:
        db[col].drop()
        print(f"  Dropped {col}")

    db.sentiment_articles.insert_many(enriched)
    print(f"  ✓ Inserted {len(enriched)} articles into sentiment_articles")

    db.sentiment_stats.insert_one(stats)
    print(f"  ✓ Inserted stats into sentiment_stats")

    db.sentiment_timeline.insert_many(timeline)
    print(f"  ✓ Inserted {len(timeline)} timeline points")

    db.sentiment_sources.insert_many(sources)
    print(f"  ✓ Inserted {len(sources)} source records")

    db.sentiment_keywords.insert_many(keywords)
    print(f"  ✓ Inserted {len(keywords)} keywords")

    client.close()

    print("\n" + "=" * 60)
    print("SUMMARY")
    print("=" * 60)
    print(f"  Total articles  : {total}")
    print(f"  Positive        : {len(pos)} ({pos_pct}%)")
    print(f"  Negative        : {len(neg)}")
    print(f"  Neutral         : {len(neu)}")
    print(f"  Overall sent.   : {stats['overall_sentiment_str']}")
    print(f"  Avg confidence  : {avg_conf}%")
    print(f"  Bias            : {stats['sentiment_bias']}")
    print("\n✅ All data seeded successfully!\n")


if __name__ == "__main__":
    asyncio.run(main())